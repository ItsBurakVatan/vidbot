
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "142.147.128.93",
                port: parseInt(6593)
            },
            bypassList: ["localhost"]
        }
    };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "uzkbddvq",
                    password: "zlk523j6taw3"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    